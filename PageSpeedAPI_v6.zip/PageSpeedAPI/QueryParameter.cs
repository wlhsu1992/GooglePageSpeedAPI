﻿
namespace PageSpeedAPI
{
    public struct QueryParam
    {
        public struct Strategy
        {
            public const string STRATEGY_UNSPECIFIED = "strategy_unspecified";
            public const string DESKTOP = "desktop";
            public const string MOBILE = "mobile";
        }

        public struct Site
        {
            public const string ETMall = "etmall";
            public const string UMall = "umall";
        }

        public struct Url
        {
            /// <summary>
            /// E大網
            /// </summary>
            public struct ETMall
            {
                public const string Index = "https://www.etmall.com.tw";
                public const string Search = Index + "/Search?keyword=iPhone";
                public const string Store = Index + "/s/16462";
                public const string CategoryL = Index + "/c1/26770";
                public const string CategoryM = Index + "/c2/51456";
                public const string CategoryS = Index + "/c3/51466";
                public const string Detail = Index + "/i/2512974";
            }

            /// <summary>
            /// E小網
            /// </summary>
            public struct METMall
            {
                public const string Index = "https://m.etmall.com.tw";
                public const string Search = Index + "/Search?keyword=iPhone";
                public const string Store = Index + "/s/16462";
                public const string CategoryL = Index + "/c1/26770";
                public const string CategoryM = Index + "/c2/51456";
                public const string CategoryS = Index + "/c3/51466";
                public const string Detail = Index + "/i/2512974";
            }

            /// <summary>
            /// U大網
            /// </summary>
            public struct UMall
            {
                public const string Index = "https://www.u-mall.com.tw";
                public const string Search = Index + "/Search?keyword=iPhone";
                public const string Store = Index + "/s/33598";
                public const string CategoryL = Index + "/c1/49143";
                public const string CategoryM = Index + "/c2/34810";
                public const string CategoryS = Index + "/c3/36507";
                public const string Detail = Index + "/i/2654184";
            }

            /// <summary>
            /// U小網
            /// </summary>
            public struct MUMall
            {
                public const string Index = "https://m.u-mall.com.tw";
                public const string Search = Index + "/Search?keyword=iPhone";
                public const string Store = Index + "/s/33598";
                public const string CategoryL = Index + "/c1/49143";
                public const string CategoryM = Index + "/c2/34810";
                public const string CategoryS = Index + "/c3/36507";
                public const string Detail = Index + "/i/2654184";
            }
        }
    }
}
